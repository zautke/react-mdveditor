/**
 * Utility function to concatenate class names. Accepts any number of
 * strings/booleans and filters out falsy values. This helper is used by
 * shadcn/ui components to conditionally merge Tailwind CSS classes.
 */
export function cn(...classes: Array<string | undefined | null | false>) {
  return classes.filter(Boolean).join(' ');
}