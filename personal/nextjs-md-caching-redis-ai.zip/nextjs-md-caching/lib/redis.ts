import { createClient, type RedisClientType } from 'redis';

let _client: RedisClientType | null = null;
let _connecting: Promise<RedisClientType> | null = null;

/**
 * Returns a singleton Redis client for the Node.js runtime.
 *
 * For serverless platforms, you may want an HTTP-based Redis client
 * (e.g., Upstash) instead of a long-lived TCP connection.
 */
export async function getRedis() {
  if (_client) return _client;
  if (_connecting) return _connecting;

  const url = process.env.REDIS_URL;
  if (!url) {
    throw new Error('Missing REDIS_URL env var');
  }

  const client = createClient({ url });
  client.on('error', (err) => {
    // eslint-disable-next-line no-console
    console.error('[redis] client error', err);
  });

  _connecting = client.connect().then(() => {
    _client = client;
    return client;
  });

  return _connecting;
}
