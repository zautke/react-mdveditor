import * as transformers from '@xenova/transformers';

let _pipe: any | null = null;
let _loading: Promise<any> | null = null;

/**
 * Generate a normalized embedding for a text string, suitable for
 * Redis Vector Sets (VADD/VSIM).
 *
 * Uses @xenova/transformers locally by default.
 */
export async function embedText(text: string): Promise<number[]> {
  if (!_pipe) {
    if (!_loading) {
      _loading = transformers.pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2').then((p) => {
        _pipe = p;
        return p;
      });
    }
    await _loading;
  }

  const out = await _pipe(text, {
    pooling: 'mean',
    normalize: true,
  });

  // Output is typically a typed array nested in an object.
  const arr = Array.from(out.data ?? out);
  return arr.map((n: any) => Number(n));
}
