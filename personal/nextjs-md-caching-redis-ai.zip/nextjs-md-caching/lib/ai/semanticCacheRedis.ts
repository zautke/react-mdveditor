import crypto from 'node:crypto';
import { getRedis } from '../redis';
import { embedText } from './embeddings';

/**
 * A practical, Redis 8+ semantic cache built on Vector Sets.
 *
 * - Stores embeddings in a Vector Set via VADD
 * - Finds nearest neighbor matches via VSIM
 * - Stores the full response as a separate key with TTL
 *
 * Why separate the response?
 * Vector-set attributes are JSON and are great for small metadata and filters,
 * but keeping large text blobs in a dedicated key is simpler and cheaper.
 */

const VSET_KEY = 'ai:cache:v1:vset';
const RESP_PREFIX = 'ai:cache:v1:resp:';

function sha1(input: string) {
  return crypto.createHash('sha1').update(input).digest('hex');
}

export type SemanticCacheHit = {
  id: string;
  score: number;
  response: string;
};

export type SemanticCachePutOptions = {
  model?: string;
  ttlSeconds?: number;
  namespace?: string;
};

export type SemanticCacheGetOptions = {
  model?: string;
  threshold?: number; // 0..1 (VSIM score)
  namespace?: string;
};

function nsFilterExpr(namespace?: string) {
  if (!namespace) return null;
  // Vector-set filter expressions operate on JSON attributes.
  return `.ns == "${namespace.replace(/"/g, '\\"')}"`;
}

/**
 * Store a prompt->response pair in Redis semantic cache.
 */
export async function semanticCachePut(
  prompt: string,
  response: string,
  opts: SemanticCachePutOptions = {},
) {
  const redis = await getRedis();
  const model = opts.model ?? 'default';
  const ttlSeconds = opts.ttlSeconds ?? 60 * 60 * 24; // 24h
  const namespace = opts.namespace ?? 'global';

  const vector = await embedText(prompt);
  const dim = vector.length;
  const id = sha1(`${model}|${namespace}|${prompt}`);

  // Store response blob separately.
  await redis.set(`${RESP_PREFIX}${id}`, response, { EX: ttlSeconds });

  // Add / update vector in the vector set.
  // VADD key VALUES <dim> <v1..vN> <element> SETATTR '{"model":"..."}'
  // node-redis doesn't (yet) have typed helpers for vector-set commands in all
  // versions, so we use sendCommand.
  const attrs = JSON.stringify({ model, ns: namespace, createdAt: Date.now() });

  const args: string[] = [
    VSET_KEY,
    'VALUES',
    String(dim),
    ...vector.map((n) => String(n)),
    id,
    'SETATTR',
    attrs,
  ];
  await redis.sendCommand(['VADD', ...args]);

  return { id, dim, ttlSeconds };
}

/**
 * Look up a prompt in the semantic cache.
 * Returns the best match if score >= threshold.
 */
export async function semanticCacheGet(
  prompt: string,
  opts: SemanticCacheGetOptions = {},
): Promise<SemanticCacheHit | null> {
  const redis = await getRedis();
  const threshold = opts.threshold ?? 0.93;
  const namespace = opts.namespace ?? 'global';

  const vector = await embedText(prompt);
  const dim = vector.length;
  const filter = nsFilterExpr(namespace);

  // VSIM key VALUES <dim> <v1..vN> WITHSCORES COUNT 1 [FILTER expr]
  const cmd: string[] = [
    'VSIM',
    VSET_KEY,
    'VALUES',
    String(dim),
    ...vector.map((n) => String(n)),
    'WITHSCORES',
    'COUNT',
    '1',
  ];
  if (filter) {
    cmd.push('FILTER', filter);
  }

  const res = await redis.sendCommand(cmd);
  if (!Array.isArray(res) || res.length < 2) return null;

  const id = String(res[0]);
  const score = Number(res[1]);
  if (!Number.isFinite(score) || score < threshold) return null;

  const response = await redis.get(`${RESP_PREFIX}${id}`);
  if (!response) return null;

  return { id, score, response };
}
