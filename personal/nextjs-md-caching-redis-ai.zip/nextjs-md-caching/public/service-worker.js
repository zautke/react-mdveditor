// A simple service worker that caches responses from the Markdown API and other
// static assets. It uses a cache‑first strategy: return cached content
// immediately if present, otherwise fetch from the network and update the
// cache. When offline and the resource isn't cached, it returns a 503
// response. See readme for more details.

const CACHE_VERSION = 'v1';
const CACHE_NAME = `md-cache-${CACHE_VERSION}`;

// Install event: can be used to precache assets. Here we skip precaching since
// markdown files are loaded on demand. You could add file URLs to the
// `precacheResources` array to cache them during installation.
self.addEventListener('install', (event) => {
  console.log('Service worker installing…');
  self.skipWaiting();
});

// Activate event: clean up old caches.
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        }),
      );
    }),
  );
  console.log('Service worker activated.');
});

// Fetch event: intercept requests and apply cache strategies. Only GET requests
// under the `/api/docs/` path are cached. Other requests fall through to the
// network.
self.addEventListener('fetch', (event) => {
  const { request } = event;
  // Only handle GET requests to our markdown API
  if (request.method === 'GET' && request.url.includes('/api/docs/')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) {
          return cached;
        }
        try {
          const response = await fetch(request);
          // Clone because response streams can only be read once
          cache.put(request, response.clone());
          return response;
        } catch (error) {
          return new Response('Offline', { status: 503, statusText: 'Offline' });
        }
      }),
    );
  }
});