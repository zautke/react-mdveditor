# Document 2

This is another sample markdown document used to demonstrate caching. Markdown
supports lists, code blocks, and more.

### List Example

- Item one
- Item two
- Item three

### Code Example

```js
function greet(name) {
  return `Hello, ${name}!`;
}

console.log(greet('world'));
```