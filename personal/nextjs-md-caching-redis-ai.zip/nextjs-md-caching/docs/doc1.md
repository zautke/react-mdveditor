# Document 1

This is the first example document. It contains **markdown** syntax and will be
rendered using the `react-markdown` package. You can create many more files in
this directory and they will automatically appear as tabs in the UI.

## Section A

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vel lorem sit
amet magna suscipit facilisis. Suspendisse potenti.

## Section B

Praesent dictum porttitor sapien, sed convallis augue consequat non. Mauris
ullamcorper, libero id consequat tincidunt, nunc lectus sollicitudin nunc, sed
rutrum turpis urna sit amet ipsum.