"use client";

import { useState, useEffect } from 'react';

/**
 * useIndexedMarkdownCache is a hook that reads and writes markdown documents to
 * IndexedDB. Given a slug, it attempts to retrieve a cached document. If
 * `markdown` is provided, the hook will store it under the slug for later
 * retrieval. The hook returns the cached content if it exists, otherwise
 * returns null.
 *
 * This implementation uses the bare IndexedDB API for simplicity. In a real
 * project you might use a wrapper library like `idb` to handle edge cases.
 */
export function useIndexedMarkdownCache(slug: string, markdown?: string) {
  const [cached, setCached] = useState<string | null>(null);

  useEffect(() => {
    let db: IDBDatabase;
    const openRequest = indexedDB.open('markdown-cache', 1);
    // Create the object store on first run
    openRequest.onupgradeneeded = () => {
      db = openRequest.result;
      if (!db.objectStoreNames.contains('files')) {
        db.createObjectStore('files');
      }
    };
    openRequest.onsuccess = () => {
      db = openRequest.result;
      const tx = db.transaction('files', 'readonly');
      const store = tx.objectStore('files');
      const getReq = store.get(slug);
      getReq.onsuccess = () => {
        const result = getReq.result;
        if (result) {
          setCached(result as string);
        } else if (markdown) {
          // Save new markdown into cache. Write operations require a separate
          // transaction.
          const writeTx = db.transaction('files', 'readwrite');
          writeTx.objectStore('files').put(markdown, slug);
          setCached(markdown);
        }
      };
    };
    openRequest.onerror = () => {
      console.warn('IndexedDB error:', openRequest.error);
    };
    // Clean up by closing the database when unmounting to avoid warnings
    return () => {
      if (db && db.close) db.close();
    };
  }, [slug, markdown]);
  return cached;
}