// Minimal in-memory cache handler for `use cache`.
//
// This follows the `cacheHandlers` interface described in Next.js docs.
// For production, consider LRU eviction, size limits, and better tag tracking.

const cache = new Map();
const pendingSets = new Map();

export default {
  async get(cacheKey, softTags) {
    const pendingPromise = pendingSets.get(cacheKey);
    if (pendingPromise) await pendingPromise;

    const entry = cache.get(cacheKey);
    if (!entry) return undefined;

    // Basic expiration check. Next.js expects you to return `undefined` for
    // missing or expired entries.
    const now = Date.now();
    if (now > entry.timestamp + entry.revalidate * 1000) return undefined;

    return entry;
  },

  async set(cacheKey, pendingEntry) {
    let resolvePending;
    const pendingPromise = new Promise((resolve) => {
      resolvePending = resolve;
    });
    pendingSets.set(cacheKey, pendingPromise);

    try {
      const entry = await pendingEntry;
      cache.set(cacheKey, entry);
    } finally {
      resolvePending?.();
      pendingSets.delete(cacheKey);
    }
  },

  async refreshTags() {
    // no-op
  },

  async getExpiration(tags) {
    // no tag timestamp tracking in this demo handler
    return 0;
  },

  async updateTags(tags, durations) {
    // Naive invalidation: scan all entries.
    for (const [key, entry] of cache.entries()) {
      if (entry.tags?.some((t) => tags.includes(t))) {
        cache.delete(key);
      }
    }
  },
};
