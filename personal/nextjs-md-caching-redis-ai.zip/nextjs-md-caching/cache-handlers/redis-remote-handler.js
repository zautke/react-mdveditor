import { getRedis } from '../lib/redis';

/**
 * Redis-backed cache handler for Next.js Cache Components.
 *
 * Used by `'use cache: remote'` and configured via `cacheHandlers.remote`.
 *
 * This implementation:
 * - Stores the CacheEntry value stream as base64 in Redis
 * - Tracks tags -> cacheKeys using Redis Sets for fast invalidation
 * - Tracks tag revalidation timestamps so soft tags can invalidate entries
 *
 * NOTE: This is a solid "enterprise" baseline but you can improve it further
 * with compression, sharding, and observability.
 */

const PREFIX = 'next:cc:v1';
const entryKey = (cacheKey) => `${PREFIX}:entry:${cacheKey}`;
const tagSetKey = (tag) => `${PREFIX}:tag:${tag}`;
const tagTsKey = (tag) => `${PREFIX}:tagts:${tag}`;

const pendingSets = new Map();

async function streamToBuffer(readableStream) {
  const reader = readableStream.getReader();
  const chunks = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks);
}

function bufferToReadableStream(buf) {
  return new ReadableStream({
    start(controller) {
      controller.enqueue(new Uint8Array(buf));
      controller.close();
    },
  });
}

function ttlSecondsFor(entry) {
  // `expire` is "hard" expiration; `revalidate` is "stale-while-revalidate".
  // Prefer expire if set, otherwise fall back to revalidate.
  const ttl = Number(entry?.expire ?? 0) || Number(entry?.revalidate ?? 0) || 0;
  // never set EX 0; let Redis keep it if unknown
  return ttl > 0 ? ttl : null;
}

export default {
  async get(cacheKey, softTags) {
    const redis = await getRedis();

    // If there is a concurrent set in this process, wait on it.
    const pending = pendingSets.get(cacheKey);
    if (pending) await pending;

    const stored = await redis.get(entryKey(cacheKey));
    if (!stored) return undefined;

    /** @type {{ value: string; tags: string[]; stale: number; timestamp: number; expire: number; revalidate: number }} */
    const data = JSON.parse(stored);

    // Basic expiry check based on the CacheEntry contract.
    const now = Date.now();
    if (data.revalidate > 0 && now > data.timestamp + data.revalidate * 1000) {
      return undefined;
    }

    // Soft-tag invalidation: if any softTag was revalidated after this entry
    // was written, treat it as a miss.
    if (softTags?.length) {
      const keys = softTags.map(tagTsKey);
      const tsValues = await redis.mGet(keys);
      let maxTs = 0;
      for (const v of tsValues) {
        const t = v ? Number(v) : 0;
        if (t > maxTs) maxTs = t;
      }
      if (maxTs && maxTs > data.timestamp) return undefined;
    }

    const buf = Buffer.from(data.value, 'base64');
    return {
      value: bufferToReadableStream(buf),
      tags: Array.isArray(data.tags) ? data.tags : [],
      stale: Number(data.stale ?? 0),
      timestamp: Number(data.timestamp ?? Date.now()),
      expire: Number(data.expire ?? 0),
      revalidate: Number(data.revalidate ?? 0),
    };
  },

  async set(cacheKey, pendingEntry) {
    const redis = await getRedis();

    // Track concurrent sets within this process so `get()` can await them.
    let resolvePending;
    const pendingPromise = new Promise((resolve) => {
      resolvePending = resolve;
    });
    pendingSets.set(cacheKey, pendingPromise);

    try {
      const entry = await pendingEntry;

      // Duplicate the stream so Next.js can continue to consume it.
      // We consume one copy to persist it.
      const [forCache, forNext] = entry.value.tee();
      entry.value = forNext;

      const buf = await streamToBuffer(forCache);
      const payload = {
        value: buf.toString('base64'),
        tags: entry.tags ?? [],
        stale: entry.stale,
        timestamp: entry.timestamp,
        expire: entry.expire,
        revalidate: entry.revalidate,
      };

      const ttl = ttlSecondsFor(entry);

      const multi = redis.multi();
      if (ttl) {
        multi.set(entryKey(cacheKey), JSON.stringify(payload), { EX: ttl });
      } else {
        multi.set(entryKey(cacheKey), JSON.stringify(payload));
      }

      // Tag -> keys index for invalidation.
      for (const tag of payload.tags) {
        multi.sAdd(tagSetKey(tag), cacheKey);
      }

      await multi.exec();
    } finally {
      resolvePending?.();
      pendingSets.delete(cacheKey);
    }
  },

  async refreshTags() {
    // Optional: pull tag state from an external service.
    // We keep tag timestamps in Redis, so there is nothing to refresh.
  },

  async getExpiration(tags) {
    // Return the most recent revalidation timestamp among these tags.
    // If you prefer to do soft-tag logic in `get()`, you can return Infinity.
    if (!tags?.length) return 0;
    const redis = await getRedis();
    const ts = await redis.mGet(tags.map(tagTsKey));
    let max = 0;
    for (const v of ts) {
      const t = v ? Number(v) : 0;
      if (t > max) max = t;
    }
    return max;
  },

  async updateTags(tags, durations) {
    // Called when tags are revalidated or expired.
    // We do immediate invalidation by:
    //   1) Recording a per-tag timestamp (for soft tag checks)
    //   2) Deleting all entries that were indexed under that tag
    if (!tags?.length) return;
    const redis = await getRedis();
    const now = Date.now();

    // Pull keys and delete in batches.
    for (const tag of tags) {
      const setKey = tagSetKey(tag);
      const members = await redis.sMembers(setKey);

      const multi = redis.multi();
      multi.set(tagTsKey(tag), String(now), {
        // Optional: keep tag timestamps around. If you pass durations.expire,
        // expire tag timestamps too.
        EX: durations?.expire ?? 60 * 60 * 24,
      });

      for (const cacheKey of members) {
        multi.del(entryKey(cacheKey));
      }
      multi.del(setKey);
      await multi.exec();
    }
  },
};
