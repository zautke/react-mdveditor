import { cache } from 'react';
import fs from 'fs/promises';
import path from 'path';
import { Suspense } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import MarkdownViewer from '../components/markdown-viewer';

// Define the directory containing markdown files. In this demo it lives in
// `nextjs-md-caching/docs`, but you can change this path to your own content
// directory. Each file name (without the .md extension) becomes a tab name.
// The docs directory sits at the project root. `process.cwd()` resolves to
// that root during build and runtime.
const docsDir = path.join(process.cwd(), 'docs');

// Caches the list of slugs so the directory is only read once per server
// instance. Using `cache()` here means the result will be reused until
// invalidated by redeploying or using a `cacheTag`/`revalidatePath` call.
const getSlugs = cache(async (): Promise<string[]> => {
  const files = await fs.readdir(docsDir);
  return files
    .filter((file) => file.endsWith('.md'))
    .map((file) => file.replace(/\.md$/, ''));
});

/**
 * The root page renders a shadcn/ui Tabs component. Each tab corresponds to a
 * markdown file in the `docs` directory. When a tab is activated, the
 * `MarkdownViewer` client component fetches and displays the content. Because
 * this component is a server component, it can asynchronously determine the
 * list of available slugs using Node APIs.
 */
export default async function Page() {
  const slugs = await getSlugs();
  if (slugs.length === 0) {
    return <p>No markdown files found in the docs directory.</p>;
  }
  const defaultSlug = slugs[0];
  return (
    <div className="p-4">
      <Tabs defaultValue={defaultSlug} className="w-full">
        <TabsList>
          {slugs.map((slug) => (
            <TabsTrigger key={slug} value={slug}>
              {slug}
            </TabsTrigger>
          ))}
        </TabsList>
        {slugs.map((slug) => (
          <TabsContent key={slug} value={slug} className="mt-4">
            {/* Use Suspense so the client component can show a fallback while
                fetching content. */}
            <Suspense fallback={<p>Loading {slug}…</p>}>
              {/* Pass only the slug to the client component. It will
                  fetch the content from the API route and handle caching
                  in IndexedDB. */}
              <MarkdownViewer slug={slug} />
            </Suspense>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}