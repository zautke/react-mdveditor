import type { Metadata } from 'next';
import '../styles/globals.css';
import ServiceWorkerRegister from '../components/service-worker-register';

// Metadata can be used to set default document metadata. Adjust as needed.
export const metadata: Metadata = {
  title: 'Markdown Tabs Demo',
  description: 'A Next.js 16 demo showing multi-tab markdown with caching.',
};

/**
 * The root layout wraps all pages. It is a server component by default, but we
 * import a small client component to register the service worker so it runs
 * only in the browser. The service worker will cache markdown files and
 * assets using the Cache API.
 */
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {/* Register the service worker on the client. */}
        <ServiceWorkerRegister />
        {children}
      </body>
    </html>
  );
}