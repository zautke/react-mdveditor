import { NextResponse } from 'next/server';
import { semanticCacheGet, semanticCachePut } from '../../../lib/ai/semanticCacheRedis';

export const runtime = 'nodejs';

/**
 * Demo: AI endpoint backed by Redis 8 semantic caching (vector sets).
 *
 * POST { prompt: string }
 * -> { answer: string, cached: boolean, score?: number }
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const prompt = typeof body?.prompt === 'string' ? body.prompt : '';
  if (!prompt) {
    return NextResponse.json({ error: 'Missing prompt' }, { status: 400 });
  }

  // 1) Semantic cache lookup
  const hit = await semanticCacheGet(prompt, { threshold: 0.94, namespace: 'demo' });
  if (hit) {
    return NextResponse.json({ answer: hit.response, cached: true, score: hit.score });
  }

  // 2) Generate an answer (replace this with your real LLM call)
  const answer = `Demo answer (replace with your LLM): ${prompt}`;

  // 3) Store result in cache
  await semanticCachePut(prompt, answer, { ttlSeconds: 60 * 60, namespace: 'demo', model: 'demo' });

  return NextResponse.json({ answer, cached: false });
}
