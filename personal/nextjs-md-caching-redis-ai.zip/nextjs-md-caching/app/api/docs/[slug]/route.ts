import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';
import { cacheLife, cacheTag } from 'next/cache';

// Directory containing markdown files relative to the project root. When
// deploying, ensure this path points to the correct location.
const docsDir = path.join(process.cwd(), 'docs');

/**
 * Read a markdown file from disk and persist it in the Cache Components
 * remote cache.
 *
 * Notes:
 * - `'use cache: remote'` will use `cacheHandlers.remote` (Redis in this demo).
 * - `cacheLife()` and `cacheTag()` must run inside the cached function scope.
 */
async function readMarkdown(slug: string): Promise<string> {
  'use cache: remote';

  // Cache profile:
  // - stale: client can reuse for 10m
  // - revalidate: server refresh in background after 10m
  // - expire: hard-expire after 1h
  cacheLife({ stale: 600, revalidate: 600, expire: 3600 });
  cacheTag(`md:${slug}`);

  const filePath = path.join(docsDir, `${slug}.md`);
  const content = await fs.readFile(filePath, 'utf8');
  return content;
}

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } },
) {
  const slug = params.slug;
  try {
    const md = await readMarkdown(slug);
    return new NextResponse(md, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
      },
    });
  } catch (err) {
    return new NextResponse('File not found', { status: 404 });
  }
}