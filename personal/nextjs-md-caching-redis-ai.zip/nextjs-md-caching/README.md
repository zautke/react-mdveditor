# Next.js 16 Markdown Tabs Demo

This project demonstrates how to build a Next.js 16 application that renders 30–45 (or more) Markdown documents in tabs using [shadcn/ui](https://ui.shadcn.com/) and implements a multi‑tier caching strategy.  It combines **browser‑side caching** (service worker + IndexedDB), **Next.js 16 cache components**, and **React performance optimisations**.  The goal is to provide near‑instant switching between tabs even when the documents are large.

## Key Features

1. **Shadcn tabs** – The UI uses `Tabs`, `TabsList`, `TabsTrigger` and `TabsContent` components (implemented in `components/ui/tabs.tsx`) to present each markdown file as a tab.
2. **Server component for tab list** – `app/page.tsx` is a server component that reads the `docs` directory at build time and lists all `.md` files.  It does not load the file contents up front; instead it passes the slug to the client component.
3. **API route with Cache Components** – The API route `app/api/docs/[slug]/route.ts` reads a markdown file and caches it on the server using the **Cache Components** model (`'use cache: remote'`). The route uses `cacheLife({ stale, revalidate, expire })` (10m / 10m / 1h) and applies a cache tag (`md:<slug>`) so documents can be invalidated on-demand.
4. **Service worker caching** – The service worker (`public/service-worker.js`) registers on the client via a small client component. It intercepts requests to `/api/docs/*`, returning cached responses from the **Cache API** if available and falling back to the network. The cache is versioned so you can invalidate all entries by bumping `CACHE_VERSION`.
5. **IndexedDB cache on the client** – The `useIndexedMarkdownCache` hook persists fetched markdown into IndexedDB. This ensures that once a document is loaded it is available offline and avoids repeated network fetches.
6. **Lazy loading and memoization** – The `MarkdownViewer` client component fetches documents on demand and caches them. Because the markdown content is stored in IndexedDB and server caches, switching back to a previously opened tab is instant. You can further optimise by memoizing the component with `React.memo` or splitting very large documents into smaller chunks.

7. **Redis 8 semantic cache for AI** – A demo endpoint `app/api/ai/route.ts` shows how to do *semantic caching* for LLM prompts/responses using Redis 8 Vector Sets (`VADD` + `VSIM`). It uses local embeddings via `@xenova/transformers` for an “all-local” demo.

## File Structure

```
nextjs-md-caching/
├─ app/
│  ├─ page.tsx               ← Server component listing tabs
│  ├─ layout.tsx             ← Root layout registering the service worker
│  └─ api/
│     └─ docs/
│        └─ [slug]/
│           └─ route.ts      ← API route returning markdown with caching
├─ components/
│  ├─ ui/
│  │  └─ tabs.tsx            ← Shadcn tabs (adapted from Radix UI)
│  ├─ markdown-viewer.tsx    ← Client component that fetches and renders Markdown
│  └─ service-worker-register.tsx ← Registers the service worker
├─ hooks/
│  └─ useIndexedMarkdownCache.ts ← IndexedDB caching hook
├─ public/
│  └─ service-worker.js      ← Service worker implementing Cache API
├─ docs/
│  └─ *.md                   ← Place your markdown documents here
├─ styles/
│  └─ globals.css            ← Minimal global styles
├─ next.config.js
├─ package.json
└─ README.md (this file)
```

## Running the Project

> **Important:** This project uses [`pnpm`](https://pnpm.io/) as the package manager.  If you don’t have it installed, install via `corepack enable pnpm` or `npm install -g pnpm`.  For Node 16+, `corepack` is available by default.

1. **Install dependencies**

   ```bash
   pnpm install
   ```

2. **Start the development server**

   ```bash
   pnpm dev
   ```

   Visit `http://localhost:3000` in your browser.  You should see two tabs (`doc1` and `doc2`) corresponding to the markdown files in the `docs` folder.  Add more `.md` files and they will automatically appear as tabs.

3. **Test caching behaviour**

   - Open DevTools → Application → Service Workers and tick the **Offline** box.  The documents you visited previously should still load because they were cached by the service worker.  When offline and a document hasn’t been visited, the API route will return a 503 response handled by the service worker.
   - Inspect **IndexedDB** → `markdown-cache` to see stored documents.
   - Watch the network tab: when switching back to a tab, no network request is fired because the document is served from IndexedDB.

4. **Adjust TTL and invalidation**

   The API route caches each file using `cacheLife({ stale, revalidate, expire })`. You can shorten or lengthen the TTL by changing those values in `app/api/docs/[slug]/route.ts`.

   To invalidate a document programmatically, call `revalidateTag('md:<slug>')` from a Server Action or route handler.

5. **Remote caching with Redis**

   This demo uses Next.js Cache Handlers:

   - `cacheHandlers.default` → in-memory Map (demo)
   - `cacheHandlers.remote` → Redis (`cache-handlers/redis-remote-handler.js`)

   Set `REDIS_URL` and start Redis, then run `pnpm dev`.

6. **Try the AI semantic cache**

   ```bash
   curl -X POST http://localhost:3000/api/ai \
     -H 'content-type: application/json' \
     -d '{"prompt":"What is the capital of France?"}'
   ```

   The first call generates a demo answer and stores it; subsequent calls with similar prompts may hit the semantic cache.

## Notes

* **Service worker scope** – In `components/service-worker-register.tsx`, the service worker is registered at the root scope (`/`). If you only want to cache markdown API responses, you can register with a more limited scope (e.g., `{ scope: '/api/docs' }`).
* **Cache size and eviction** – Browsers may delete caches when storage is low, so ensure your app gracefully handles missing cache entries. IndexedDB offers large quotas but is also subject to eviction; monitor usage and clean up unused entries periodically.
* **Security** – Service workers require HTTPS in production. Running over HTTP (except on `localhost`) may lead to security vulnerabilities.
* **Additional optimisations** – For very large documents, consider splitting content into smaller sections or using virtualisation (e.g., `react-window`) so that only the visible portion of the document is rendered. You can also memoize the Markdown viewer or pre‑parse Markdown during the build step to avoid runtime parsing costs.

Happy hacking!