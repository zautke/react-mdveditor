import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);

/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  // Enable explicit caching with Cache Components. When set to true, no
  // components or functions are cached implicitly. Use the `cache()` utility or
  // the `use cache` directive to persist expensive computations or data.
  cacheComponents: true,

  /**
   * Cache handlers (plural) are used by Cache Components:
   *  - 'use cache' -> default handler
   *  - 'use cache: remote' -> remote handler
   *
   * We keep the default handler in-memory, but persist remote caches in Redis.
   */
  cacheHandlers: {
    // Use Next.js' built-in default handler by omitting `default`, or provide
    // your own. We show a tiny memory handler for completeness.
    default: require.resolve('./cache-handlers/memory-handler.js'),
    remote: require.resolve('./cache-handlers/redis-remote-handler.js'),
  },

  /**
   * cacheHandler (singular) is for ISR / route handler response caching.
   * It's optional and separate from Cache Components. Enable if you want to
   * persist ISR caches in Redis as well.
   */
  // cacheHandler: require.resolve('./cache-handler.js'),
  // cacheMaxMemorySize: 0,
};

export default nextConfig;