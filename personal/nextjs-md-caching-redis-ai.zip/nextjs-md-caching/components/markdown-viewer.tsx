"use client";

import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useIndexedMarkdownCache } from '../hooks/useIndexedMarkdownCache';

interface MarkdownViewerProps {
  /** The slug corresponding to the markdown file. */
  slug: string;
}

/**
 * MarkdownViewer fetches markdown content for a given slug and renders it using
 * react-markdown. It first checks an IndexedDB cache; if the content exists
 * locally, it loads instantly. Otherwise it fetches from the API route and
 * stores the result in the cache for subsequent visits. A loading message is
 * shown while content is being retrieved.
 */
export default function MarkdownViewer({ slug }: MarkdownViewerProps) {
  const [markdown, setMarkdown] = useState<string | null>(null);
  // Attempt to retrieve a cached version on mount. Once the content is fetched
  // below, it will be saved to IndexedDB via the hook.
  const cached = useIndexedMarkdownCache(slug, markdown ?? undefined);

  useEffect(() => {
    // If we already have cached content, use it immediately.
    if (cached) {
      setMarkdown(cached);
      return;
    }
    // Otherwise fetch from the API. The API returns plain text. Once fetched,
    // save it into state; the hook will persist it to IndexedDB.
    fetch(`/api/docs/${slug}`)
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to fetch markdown: ${res.status}`);
        return res.text();
      })
      .then((text) => {
        setMarkdown(text);
      })
      .catch((err) => {
        console.error(err);
        setMarkdown('Error loading markdown.');
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug, cached]);

  if (!markdown) {
    return <p>Loading...</p>;
  }
  return <ReactMarkdown remarkPlugins={[remarkGfm]}>{markdown}</ReactMarkdown>;
}