"use client";

import { useEffect } from 'react';

/**
 * Registers the service worker on the client. This hook runs once on mount and
 * registers `public/service-worker.js` if supported by the browser. The
 * service worker caches markdown files and other assets to provide offline
 * support and faster repeat navigation. Errors are logged to the console.
 */
export default function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/service-worker.js')
        .then((registration) => {
          console.log('Service worker registered with scope:', registration.scope);
        })
        .catch((error) => {
          console.error('Service worker registration failed:', error);
        });
    }
  }, []);
  return null;
}